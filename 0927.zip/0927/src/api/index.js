/*
* @Author: cdroid
* @Date:   2018-01-05 18:55:15
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-17 20:37:43
*/

import * as login from './login'
import * as user from './system/user'
import * as role from './system/role'
import * as permission from './system/permission'
import * as simulateAskTest from './base/simulateAskTest'
import * as mainMid from './mainMid'
export default Object.assign({}, login, user, role, permission, simulateAskTest, mainMid)
