/*
* @Author: cdroid
* @Date:   2018-03-28 10:44:15
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-14 18:12:45
*/
import {axios, midautumn} from './../raiis-axios'

// let defaultType = 'robot'
// export const getSimulateAskTest = () => {
//     let url = `http://59.60.12.55:9090/robot/query/question`
//     return {
//         name: 'getSimulateAskTest',
//         type: defaultType,
//         url: url,
//         requetType: 'GET',
//         remark: '获取模拟问讯测试答案',
//         go: params => { return axios.get(url + '/' + params).then(res => res.data) }
//     }
// }
let defaultType = 'midautumn'
export const getAuthAccess = () => {
    let url = `${midautumn}/auth/do`
    return {
        name: 'getAuthAccess',
        type: defaultType,
        url: url,
        requetType: 'GET',
        remark: '删除一条机型座位等级分类记录',
        go: params => { return axios.get(url).then(res => res.data) }
    }
}
