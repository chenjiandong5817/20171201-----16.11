/*
* @Author: cdroid
* @Date:   2018-09-17 20:26:55
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-17 20:26:55
*/
otherMid.js