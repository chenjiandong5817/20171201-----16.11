/*
* @Author: cdroid
* @Date:   2017-10-18 11:09:30
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-22 18:52:06
*/

/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:49:08
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-05-25 10:49:33
 * @Description:  Login操作的API
 */
import {axios, midautumn} from './raiis-axios'

let defaultType = 'mainMid'

// 获取微信SDK的配置
export const getWXJSDK = () => {
  let url = `${midautumn}/auth/js-sdk-info`
  return {
    name: 'getWXJSDK',
    type: defaultType,
    url: url,
    requetType: 'POST',
    remark: '获取微信SDK',
    go: params => { return axios.post(url, params).then(res => res.data) }
  }
}

// 获取账号的相关信息(直接调用，token的值放在header里面了)
export const getUserInfo = () => {
    let url = `${midautumn}/account/info`
    return {
        name: 'getUserInfo',
        type: defaultType,
        url: url,
        requetType: 'GET',
        remark: '获取用户相关信息',
        go: params => { return axios.get(url).then(res => res.data) }
    }
}

// 创建主题一个用户对应一个主题(直接调用，token的值放在header里面了)
export const createTheme = () => {
    let url = `${midautumn}/assist/create-theme`
    return {
        name: 'createTheme',
        type: defaultType,
        url: url,
        requetType: 'POST',
        remark: '创建主题',
        go: params => { return axios.post(url).then(res => res.data) }
    }
}

// 通过themeid获取主题
export const getThemeInfo = () => {
    let url = `${midautumn}/assist/theme-bref`
    return {
        name: 'getThemeInfo',
        type: defaultType,
        url: url,
        requetType: 'GET',
        remark: '获取主题信息',
        go: params => { return axios.get(url + '/' + params).then(res => res.data) }
    }
}

// 获取所有助力排行
export const getAllAsisstanceRank = () => {
    let url = `${midautumn}/assist/total-rank`
    return {
        name: 'getAllAsisstanceRank',
        type: defaultType,
        url: url,
        requetType: 'GET',
        remark: '获取所有助力排行',
        go: params => { return axios.get(url + '/' + params).then(res => res.data) }
    }
}

// 获取助力好友列表
export const getFriendHelpList = (themeId, page) => {
    let url = `${midautumn}/assist/${themeId}/asist-list/${page}`
    return {
        name: 'getFriendHelpList',
        type: defaultType,
        url: url,
        requetType: 'GET',
        remark: '获取助力好友列表',
        go: params => { return axios.get(url).then(res => res.data) }
    }
}

// 助力执行
export const doAssistance = (themeId) => {
    let url = `${midautumn}/assist/${themeId}/do`
    return {
        name: 'doAssistance',
        type: defaultType,
        url: url,
        requetType: 'POST',
        remark: '执行助力',
        go: params => { return axios.post(url).then(res => res.data) }
    }
}

export const getCouponSelf = () => {
    let url = `${midautumn}/coupon/get-coupon`
    return {
        name: 'getCouponSelf',
        type: defaultType,
        url: url,
        requetType: 'POST',
        remark: '获取优惠券',
        go: params => { return axios.post(url, params).then(res => res.data) }
    }
}

// 获取用户是否关注公众号
export const judgeIsNotWatch = () => {
    let url = `${midautumn}/auth/is-follow`
    return {
        name: 'judgeIsNotWatch',
        type: defaultType,
        url: url,
        requetType: 'GET',
        remark: '获取是否关注',
        go: params => { return axios.get(url).then(res => res.data) }
    }
}
