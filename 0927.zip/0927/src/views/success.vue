/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:55:39
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-06-01 10:40:50
 * @Description:  登陆界面
 */
<template>
  <div style="overflow: hidden;">
    {{ token }}
  </div>
</template>

<script>
  export default {
    data () {
      return {
      	token: null
      }
    },
    methods: {
    },
    mounted () {
      var meToo = sessionStorage.getItem('meToo')
      var otherThemeId = sessionStorage.getItem('otherThemeId')
      this.token = this.$route.params.param1
      localStorage.setItem('token', this.token)
      if (meToo === '1') {
        this.$router.push({ path: '/TheMidAutumnSelf' })
      } else {
        if (otherThemeId) {
          this.$router.push({ path: '/TheMidAutumnMain' })
        } else {
          this.$router.push({ path: '/TheMidAutumnSelf' })
        }
      }
    }
  }
</script>

<style>
</style>
