/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:55:39
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-06-01 10:40:50
 * @Description:  登陆界面
 */
<template>
  <div style="overflow: hidden;">
    <!-- 主页面容器 -->
    <div>
    	元翔专车中秋活动规则！
    </div>
  </div>
</template>

<script>
  // import { robotRequestLogin } from '../api/login'
  // import qs from 'qs'
  // import API from './../api'
  export default {
    data () {
      return {
        isNotLessOneDay: false,
        isNotFromOther: false
      }
    },
    methods: {
      // this.$router.push('/simulateAskTest')
      // getAuthAccess () {
        // window.location.href = 'http://192.168.137.101:5555/auth/do'
      // }
    },
    mounted () {
      // this.getAuthAccess()
      // console.log('this.wx', this.wx)
    }
  }
</script>

<style>
</style>
