/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:55:39
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-06-01 10:40:50
 * @Description:  登陆界面
 */
<template>
  <div v-if="loading"></div>
  <div style="overflow: hidden;" class="main" v-else>
    <!-- 设置图片全部使用绝对定位 -->
    <!-- 主背景图片 -->
    <div class="background_main">
      <img src="./../../static/background0920_color.png">
    </div>
    <!-- 左上图标 -->
    <div class="background_left_top">
      <img src="./../../static/background_left_top.png">
    </div>
    <!-- 汽车上部文字 -->
    <div class="background_top_word">
      <img src="./../../static/background_top_word.png">
    </div>
    <!-- 汽车图片 -->
    <div class="background_car">
      <img src="./../../static/background_car.png">
    </div>
    <!-- 主页面容器 -->
    <div class="main_panel">
      <!-- 规则按钮 -->
      <el-row class="rule_panel">
        <el-col :span="19" class="rule_button_panel">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="5" class="rule_button_panel">
          <div>
            <el-button size="small" round @click="getRule">活动规则</el-button>
          </div>
        </el-col>
      </el-row>
      <!-- 空白部分，占面积 -->
      <el-row class="blank_panel">
      </el-row>
      <!-- 倒计时部分_小于二十四小时的情况 -->
      <el-row class="time_panel" v-show="isNotLessOneDay">
        <el-col :span="5">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="14">
          <!-- 没有多余的部分，里面显示的就是时间 -->
          <el-row class="time_show_panel">
            <div class="time_word" style="margin-left: 15px;margin-top: 9px;">活动倒计时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">2</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">2</div>
            </div>
            <div class="time_word">时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">3</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">3</div>
            </div>
            <div class="time_word">分</div>
          </el-row>
        </el-col>
        <el-col :span="5">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
      </el-row>
      <!-- 倒计时部分_大于二十四小时的情况 -->
      <el-row class="time_panel" v-show="!isNotLessOneDay">
        <el-col :span="3">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="18">
          <!-- 没有多余的部分，里面显示的就是时间 -->
          <el-row class="time_show_panel">
            <div class="time_word" style="margin-left: 15px;margin-top: 9px;">活动倒计时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityDay1 }}</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityDay2 }}</div>
            </div>
            <div class="time_word">天</div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityHour1 }}</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityHour2 }}</div>
            </div>
            <div class="time_word">时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityMinute1 }}</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityMinute2 }}</div>
            </div>
            <div class="time_word">分</div>
          </el-row>
        </el-col>
        <el-col :span="3">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
      </el-row>
      <!-- 排名的背景图片 -->
      <div class="background_rank">
        <img src="./../../static/main10.png">
      </div>
      <!-- 描述部分 -->
      <el-row class="rank_panel">
        <el-col :span="2">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <!-- 时间没有结束的情况 -->
        <el-col :span="20" class="rank_show_panel" v-show="isEnd">
          <el-row style="position: absolute;top: 20px;left: 85px;font-size: 10px;">
            <div style="display: inline-block;color: #698EAD;">已获得助力：</div>
            <div style="display: inline-block;color: #0d9992;font-size: 50px;">{{ otherThemeObj.assistNum }}</div>
            <div style="display: inline-block;color: #0d9992;font-size: 20px;">次</div>
          </el-row>
          <el-row style="position: absolute;top: 85px;left: 85px;font-size: 10px;">
            <div style="display: inline-block;color: #698EAD;">最终排名：</div>
            <div style="display: inline-block;font-size: 17px;color: #0d9992;">第</div>
            <div style="display: inline-block;font-size: 17px;color: #0d9992;">{{ otherThemeObj.rank }}</div>
            <div style="display: inline-block;font-size: 17px;color: #0d9992;">名</div>
            <div style="display: inline-block"></div>
          </el-row>
          <div class="rank_tag_main" v-show="isShowRankTag">
            <img src="./../../static/rank_tag_0925.png">
          </div>
        </el-col>
        <!-- 时间结束的情况 -->
        <el-col :span="20" class="rank_show_panel" v-show="!isEnd">
          <el-row class="rank_top">
            <div class="rank_word">距离下一个折扣还有</div>
            <div class="rank_number">{{ assistanceNeedNumber1 }}</div>
            <div class="rank_number">{{ assistanceNeedNumber2 }}</div>
            <div class="rank_number">{{ assistanceNeedNumber3 }}</div>
            <div class="rank_word">次</div>
          </el-row>
          <el-row class="rank_bottom">
            <div class="rank_word">TA暂列第</div>
            <div class="rank_number">{{ activityOtherRank1 }}</div>
            <div class="rank_number">{{ activityOtherRank2 }}</div>
            <div class="rank_number">{{ activityOtherRank3 }}</div>
            <div class="rank_number">{{ activityOtherRank4 }}</div>
            <div class="rank_number">{{ activityOtherRank5 }}</div>
            <div class="rank_word">名</div>
          </el-row>
        </el-col>
        <el-col :span="2">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
      </el-row>
      <!-- 操作背景图片 -->
      <div class="background_operate">
        <img src="./../../static/main11.png">
      </div>
      <!-- 操作按钮部分_从别人的页面进来的情况 -->
      <el-row class="operate_panel" v-show="isNotFromOther">
        <!-- 按钮图片左边 -->
        <div class="background_button_left">
          <img @click="helpAssistance" v-show="!isEnd" src="./../../static/211.png">
        </div>
        <!-- 按钮图片右边 -->
        <div class="background_button_right">
          <img @click="ISassistance" v-show="!isEnd" src="./../../static/212.png">
        </div>
      </el-row>
      <!-- 操作按钮部分_直接进来的情况 -->
      <el-row class="operate_panel" v-show="!isNotFromOther">
        <el-col :span="2">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="20" class="operate_show_panel">
          <div class="operate_direct">
            <el-button type="success" round>我要助力</el-button>
          </div>
        </el-col>
        <el-col :span="2">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
      </el-row>
      <div class="activity-prize-backgroud">
        <div class="activity-prize-inner">
          <div class="title">
            <div class="title-font-prize">活动奖品</div>
            <img src="./../../static/assistance_h5_title.png">
          </div>

          <div class="middle-layout">
            <div @click="$router.push({ path: '/PrizeOne' })">
              <div class="prize-title">一等奖 (第1名)</div>
              <img src="./../../static/one_prize.png">
              <div style="width:130px">厦门佰翔五通酒店豪华海景房+自助晚餐券 (1名)</div>
            </div>
            <div @click="$router.push({ path: '/PrizeTwoThree' })">
              <div class="prize-title">二等奖 (第2~3名)</div>
              <img src="./../../static/two_prize.png">
              <div style="width:130px">福州佰翔空港花园酒店尊品房+自助午餐券 (2名)</div>
            </div>
          </div>

          <div class="middle-layout">
            <div @click="$router.push({ path: '/PrizeTwoThree' })">
              <div class="prize-title">三等奖 (第4~7名)</div>
              <img src="./../../static/three_prize.png">
              <div style="width:130px">福州佰翔空港花园酒店花园房+自助午餐券 (4名)</div>
            </div>
            <div onclick="window.open('http://t.cn/EvSQWyY','_self')">
              <div class="prize-title">四等奖 (第8~17名)</div>
              <img src="./../../static/four_prize.png">
              <div style="width:130px">佰翔手礼网三星报喜敢当茶礼盒 (10名)</div>
            </div>
          </div>

          <div class="middle-layout">
            <div style="text-align: center">
              <div class="prize-title">特别奖(18-158名排名尾号带“8”的)</div>
              <img src="./../../static/special_prize.png">
              <div style="width:200px;">元翔专车福州/厦门地区无门槛 188送机券一张(15名)</div>
            </div>
          </div>

          <div class="title" style="position: relative">
            <div class="title-font-sponsor">活动赞助商</div>
            <img src="./../../static/assistance_h5_title.png">
          </div>

          <div class="bottom-layout">
            <div>
              <img src="./../../static/sponsor-1.png">
            </div>
            <div>
              <img src="./../../static/sponsor-2.png">
            </div>
          </div>
          <div class="bottom-layout">
            <div>
              <img src="./../../static/sponsor-3.png">
            </div>
            <div>
              <img src="./../../static/sponsor-4.png">
            </div>
          </div>

          <div class="copyright">
            <div>活动主办方：元翔空港快线</div>
            <div>本次活动技术支持：厦门兆翔科技</div>
          </div>
        </div>
      </div>
      <div class="bottom-background-img"><img src="./../../static/assistance_h5_bottom.png"></div>
    </div>
    <!-- 弹出框用于让用户关注该公众号 -->
    <div class="is_not_watch_this">
      <el-dialog
        title=""
        :visible.sync="isNotWatchThisVisiable"
        width="30%"
        center>
        <div class="is_not_watch_this_background">
          <img src="./../../static/isnotwatchthis.png">
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
  import globalData from './../common/config/global'
  import API from './../api'
  export default {
    data () {
      return {
        // 是否是一天之内
        isNotLessOneDay: false,
        // 是否是从别人哪里来的链接
        isNotFromOther: true,
        // 活动倒计时的天
        activityDay1: null,
        activityDay2: null,
        // 活动倒计时的小时
        activityHour1: null,
        activityHour2: null,
        // 活动倒计时的分
        activityMinute1: null,
        activityMinute2: null,
        // 助力次数
        assistanceNeedNumber1: null,
        assistanceNeedNumber2: null,
        assistanceNeedNumber3: null,
        // 活动排名
        activityOtherRank1: null,
        activityOtherRank2: null,
        activityOtherRank3: null,
        activityOtherRank4: null,
        activityOtherRank5: null,
        otherThemeObj: {},
        // -1是未关注，1是关注
        isNotWatchThis: null,
        // 关注图片的弹出框
        isNotWatchThisVisiable: false,
        loading: false,
        isEnd: false,
        isShowRankTag: false
      }
    },
    methods: {
      // 获得规则详情
      getRule () {
        this.$router.push({ path: '/Explain' })
      },
      // 获得活动的剩余时间
      getActivityTime (days, hours, minutes) {
        var day = String(days)
        var hour = String(hours)
        var minute = String(minutes)
        // 天的情况
        if (day.length === 1) {
          this.activityDay1 = '0'
          this.activityDay2 = day
        }
        if (day.length === 2) {
          this.activityDay1 = day[0]
          this.activityDay2 = day[1]
        }
        // 小时的情况
        if (hour.length === 1) {
          this.activityHour1 = '0'
          this.activityHour2 = hour
        }
        if (hour.length === 2) {
          this.activityHour1 = hour[0]
          this.activityHour2 = hour[1]
        }
        // 分钟的情况
        if (minute.length === 1) {
          this.activityMinute1 = '0'
          this.activityMinute2 = minute
        }
        if (minute.length === 2) {
          this.activityMinute1 = minute[0]
          this.activityMinute2 = minute[1]
        }
      },
      getConditionInfo () {
        // 获得排名直接拿
        var nowRank = String(this.otherThemeObj.rank)
        // 获得他现在的次数
        var nowTimes = this.otherThemeObj.assistNum
        // 距离下一个阶梯还有多少次
        var nextRankNeedTime = null
        // 获取活动规则数据
        var activityRuleData = globalData.ACTIVITYRULEDATA
        // 计算距离下一个折扣还要助力多少次
        for (var i = 0; i < activityRuleData.length; i++) {
          if ((nowTimes > activityRuleData[i].assistance || nowTimes === activityRuleData[i].assistance) && nowTimes < activityRuleData[i + 1].assistance) {
            nextRankNeedTime = (activityRuleData[i + 1].assistance - nowTimes).toString()
          }
          if (nowTimes < 8) {
            nextRankNeedTime = (8 - nowTimes).toString()
          }
        }
        // 别人需要次数的情况
        if (nextRankNeedTime.length === 1) {
          this.assistanceNeedNumber1 = '0'
          this.assistanceNeedNumber2 = '0'
          this.assistanceNeedNumber3 = nextRankNeedTime[0]
        }
        if (nextRankNeedTime.length === 2) {
          this.assistanceNeedNumber1 = '0'
          this.assistanceNeedNumber2 = nextRankNeedTime[0]
          this.assistanceNeedNumber3 = nextRankNeedTime[1]
        }
        if (nextRankNeedTime.length === 3) {
          this.assistanceNeedNumber1 = nextRankNeedTime[0]
          this.assistanceNeedNumber2 = nextRankNeedTime[1]
          this.assistanceNeedNumber3 = nextRankNeedTime[2]
        }
        // 别人的排名情况
        if (nowRank.length === 1) {
          this.activityOtherRank1 = 0
          this.activityOtherRank2 = 0
          this.activityOtherRank3 = 0
          this.activityOtherRank4 = 0
          this.activityOtherRank5 = nowRank
        }
        if (nowRank.length === 2) {
          this.activityOtherRank1 = 0
          this.activityOtherRank2 = 0
          this.activityOtherRank3 = 0
          this.activityOtherRank4 = nowRank[0]
          this.activityOtherRank5 = nowRank[1]
        }
        if (nowRank.length === 3) {
          this.activityOtherRank1 = 0
          this.activityOtherRank2 = 0
          this.activityOtherRank3 = nowRank[0]
          this.activityOtherRank4 = nowRank[1]
          this.activityOtherRank5 = nowRank[2]
        }
        if (nowRank.length === 4) {
          this.activityOtherRank1 = 0
          this.activityOtherRank2 = nowRank[0]
          this.activityOtherRank3 = nowRank[1]
          this.activityOtherRank4 = nowRank[2]
          this.activityOtherRank5 = nowRank[3]
        }
        if (nowRank.length === 5) {
          this.activityOtherRank1 = nowRank[0]
          this.activityOtherRank2 = nowRank[1]
          this.activityOtherRank3 = nowRank[2]
          this.activityOtherRank4 = nowRank[3]
          this.activityOtherRank5 = nowRank[4]
        }
      },
      // 帮他助力的钩子
      helpAssistance () {
        if (this.isNotWatchThis === -1) {
          this.isNotWatchThisVisiable = true
          console.log('你没有关注该公众号')
        }
        if (this.isNotWatchThis === 1) {
          var otherThemeId = sessionStorage.getItem('otherThemeId')
          API.doAssistance(otherThemeId).go().then((data) => {
            if (data.status === 1) {
              this.getOtherTheme()
              alert(data.message)
            }
            if (data.status === -1) {
              alert(data.message)
            }
            if (data.status === -2) {
              window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
            }
          })
        }
        // 发送相关数据给后端，后端返回给我
      },
      // 我也要助力的钩子
      ISassistance () {
        sessionStorage.setItem('meToo', 1)
        // 跳转到另外一个地址
        if (this.isNotWatchThis === -1) {
          this.isNotWatchThisVisiable = true
          console.log('你没有关注该公众号')
        }
        if (this.isNotWatchThis === 1) {
          this.$router.push({ path: '/TheMidAutumnSelf' })
        }
      },
      // 得到别人的主题信息
      getOtherTheme () {
        var otherThemeId = sessionStorage.getItem('otherThemeId')
        API.getThemeInfo().go(otherThemeId).then((data) => {
          if (data.status === 1) {
            this.otherThemeObj = Object.assign({}, data.data)
            // 排名皇冠------start
            if (this.otherThemeObj.rank === 1 || this.otherThemeObj.rank === 2 || this.otherThemeObj.rank === 3) {
              this.isShowRankTag = true
            }
            // ----------------end
            this.wxShareOperate()
            this.wxShareFriend()
            // 获取剩余的秒数
            var leftMinutes = parseInt((parseInt(this.otherThemeObj.endTime) - parseInt((new Date()).valueOf())) / 1000 / 60)
            // 给定时器传结束的时间
            this.getTimer(leftMinutes)
            this.getConditionInfo()
          }
          if (data.status === -1) {
            this.$router.push('/TheMidAutumnSelf')
          }
          if (data.status === -2) {
            window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
          }
        })
      },
      // 设置定时器
      getTimer (leftMinutes) {
        var minutes = null
        var hours = null
        var days = null
        // 获得天数
        days = parseInt(leftMinutes / (60 * 24))
        // 获得小时数
        hours = parseInt(parseInt(leftMinutes % (60 * 24)) / 60)
        // 获得分钟数
        minutes = parseInt((leftMinutes % (60 * 24)) % 60)
        // 先赋值
        this.getActivityTime(days, hours, minutes)
        var _this = this
        var timer = setInterval(function () {
            minutes = minutes - 1
            if (minutes < 0) {
              minutes = 59
              hours = hours - 1
            }
            if (hours < 0) {
              hours = 23
              days = days - 1
            }
            // 每分钟赋值一次
            _this.getActivityTime(days, hours, minutes)
            if (leftMinutes === 0 || leftMinutes < 0) {
              minutes = 0
              hours = 0
              days = 0
              this.isEnd = true
              clearInterval(timer)
            }
        }, 60 * 1000)
        if (leftMinutes === 0 || leftMinutes < 0) {
          minutes = 0
          hours = 0
          days = 0
          this.getActivityTime(days, hours, minutes)
          this.isEnd = true
          clearInterval(timer)
        }
      },
      getIntoWx () {
        this.getOtherTheme()
      },
      // 判断是否关注
      judgeIsNotWatch () {
        API.judgeIsNotWatch().go().then((data) => {
          this.isNotWatchThis = data.status
          if (data.status === -2) {
            window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
          }
        })
      },
      // 获取微信配置
      getWXConfigShare () {
        return new Promise(resolve => {
          API.getWXJSDK().go({url: encodeURIComponent(location.href)}).then((data) => {
            if (data.status === 1) {
              this.wx.config({
                debug: false,
                appId: data.data.appId,
                timestamp: data.data.timestamp,
                nonceStr: data.data.nonceStr,
                signature: data.data.signature,
                jsApiList: ['onMenuShareAppMessage', 'onMenuShareTimeline']
              })
              this.wx.error(function (res) {
                // alert(res.errMsg)
                if (res.errMsg.indexOf('invalid')) {
                  // window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
                }
              })
              this.wx.ready(function () {
                resolve()
              })
            }
          })
        })
      },
      repeatConfig () {
        this.loading = true
        this.getWXConfigShare().then(() => {
          this.loading = false
          this.$nextTick(() => {
            this.getIntoWx()
          })
        })
      },
      reSetAlert () {
        window.alert = function (name) {
          var iframe = document.createElement('IFRAME')
          iframe.style.display = 'none'
          iframe.setAttribute('src', 'data:text/plain,')
          document.documentElement.appendChild(iframe)
          window.frames[0].window.alert(name)
          iframe.parentNode.removeChild(iframe)
        }
      },
      wxShareOperate () {
        let _this = this
        this.wx.onMenuShareAppMessage({
          title: '重要通知：您有一张88元无门槛接送机抵用券等待领取', // 分享标题
          desc: '元翔专车邀你助力，获88元无门槛接送机抵用券，还有价值2688元豪华海景酒店+自助餐等您领取', // 分享描述
          link: location.href.split('#')[0] + '#/TheMidAutumnMain?themeId=' + _this.otherThemeObj.themeId,
          imgUrl: 'http://yxzq.yxzc01.com/static/share_img_link.png', // 分享图标
          success: function () {
            console.log(location.href.split('?from=singlemessage&isappinstalled=0#')[0] + '#/TheMidAutumnMain?themeId=' + _this.otherThemeObj.themeId)
            // 用户确认分享后执行的回调函数
          },
          error: function () {
            alert('请重新刷新页面！')
          },
          cancel: function () {
            // 用户取消分享后执行的回调函数
          }
        })
      },
      wxShareFriend () {
        let _this = this
        this.wx.onMenuShareTimeline({
          title: '重要通知：您有一张88元无门槛接送机抵用券等待领取',
          link: location.href.split('#')[0] + '#/TheMidAutumnMain?themeId=' + _this.otherThemeObj.themeId,
          imgUrl: 'http://yxzq.yxzc01.com/static/share_img_link.png',
          success: function () {
            console.log(location.href.split('?from=singlemessage&isappinstalled=0#')[0] + '#/TheMidAutumnMain?themeId=' + _this.otherThemeObj.themeId)
          },
          cancel: function () {
            console.log(2)
          }
        })
      },
      getOtherThemeId () {
        var tag = 1
        tag = tag + Number(sessionStorage.getItem('otherTag'))
        if (tag === 1) {
          sessionStorage.setItem('otherTag', 1)
          var otherThemeId = location.href.split('themeId=')[1]
          sessionStorage.setItem('otherThemeId', otherThemeId)
        }
      }
    },
    mounted () {
      this.reSetAlert()
      this.getOtherThemeId()
      this.judgeIsNotWatch()
      // 加载微信配置后，加载用户数据
      this.repeatConfig()
    }
  }
</script>

<style>
  .main_panel {
    width: 375px;
    height: 1645px;
    z-index: 10;
    position: static;
  }
  .rule_panel {
    height: 100px;
  }
  .blank_panel {
    height: 200px;
  }
  .time_panel {
    height: 50px;
  }
  .rank_panel {
    height: 160px;
    z-index: 6;
  }
  .operate_panel {
    position: relative;
    height: 100px;
    z-index: 6
  }
  /*设置规则按钮*/
  .rule_button_panel .el-button--small {
    border-radius: 20px!important;
    background-color: black;
    color: white!important;
    opacity: 0.3;
  }
  .rule_button_panel {
    margin-top: 20px;
  }
  .time_show_panel {
    margin-top: 10px;
    height: 40px;
    background-color: #105cc2;
    border-radius: 10px 10px 0 0;
  }
  .time_word {
    display: inline-block;
    font-size: 15px;
    color: white;
  }
  .time_number {
    display: inline-block;
    width: 15px;
    height: 23px;
    font-size: 23px;
    color: black;
    background-color: white;
  }
  .main .rank_show_panel {
    height: 160px;
    position: static;
  }
  .main .rank_top {
    position: absolute;
    top: 35px;
    left: 70px;
  }
  .main .rank_bottom {
    position: absolute;
    top: 75px;
    left: 70px;
  }
  .main .rank_word {
    display: inline-block;
    font-size: 18px;
  }
  .main .rank_number {
    display: inline-block;
    width: 15px;
    height: 28px;
    color:  white;
    font-size: 25px;
    background-color: #5accc3;
  }
  .main .operate_show_panel {
    height: 100px;
    position: static;
  }
  .main .operate_left {
    display: inline-block;
    position: absolute;
    top: 25px;
    left: 70px;
  }
  .main .operate_right {
    display: inline-block;
    position: absolute;
    top: 25px;
    left: 215px;
  }
  .main .operate_direct {
    display: inline-block;
    position: absolute;
    top: 25px;
    left: 140px;
  }
  .operate_left .el-button {
    background-color: #ffe241;
    border-radius: 20px;
  }
  .operate_right .el-button {
    background-color: #ffe241;
    border-radius: 20px;
  }
  .operate_direct .el-button {
    background-color: #cccc2b;
    border-radius: 20px;
  }
  .background_main img {
    width: 375px;
    height: 1646px;
    position: absolute;
  }
  .background_rank img {
    position: absolute;
    width: 375px;
    height: 185px;
    z-index: 5;
    top: 335px;
  }
  .background_operate img {
    position: absolute;
    width: 335px;
    height: 70px;
    z-index: 5;
    left: 20px;
    top: 515px;
  }
    /*抵用券弹出框的关闭按钮*/
  .is_not_watch_this .el-dialog__headerbtn {
    position: absolute!important;
    right: -15px!important;
    top: -15px!important;
    background-color: black!important;
    opacity: 0.3!important;
    border-radius: 30px!important;
    width: 30px!important;
    height: 30px!important;
  }
  .is_not_watch_this .el-dialog {
    width: 80%!important;
    top: 35%!important;
  }
  .is_not_watch_this .el-dialog__header {
    padding-top: 5px!important;
    padding-right: 5px!important;
    padding-bottom: 0px!important;
    padding-left: 5px!important;
  }
  .is_not_watch_this .el-dialog__body {
    padding-top: 0!important;
    padding-right: 5px!important;
    padding-bottom: 5px!important;
    padding-left: 5px!important;
  }
  .is_not_watch_this_background {
    width: 100%;
  }
  .is_not_watch_this_background img {
    width: 100%;
  }
  .main .background_button_left {
    position: absolute;
    left: 45px;
    top: 15px;
  }
  .main .background_button_left img {
    width: 130px;
    height: 50px;
  }
  .main .background_button_right {
    position: absolute;
    left: 200px;
    top: 15px;
  }
  .main .background_button_right img {
    width: 130px;
    height: 50px;
  }
  .activity-prize-backgroud {
    position: relative;
    background: linear-gradient(to right, #0e6ec7 , #1347bb);
    width: 337px;
    margin: 0 auto;
    padding: 10px;
    box-sizing: border-box;
    height: 1030px;
  }
  .activity-prize-backgroud .activity-prize-inner{
    background-color: #fff;
    height: 100%;
  }
  .activity-prize-backgroud .activity-prize-inner .title img{
    width: 100%;
  }
  .activity-prize-backgroud .activity-prize-inner .title .title-font-prize{
    position: absolute;
    top: 25px;
    left: 132px;
    color: white;
    font-size: 18px;
  }
  .activity-prize-backgroud .activity-prize-inner .title .title-font-sponsor{
    position: absolute;
    top: 16px;
    left: 112px;
    color: white;
    font-size: 18px;
  }
  .activity-prize-backgroud .activity-prize-inner .middle-layout{
    display: flex;
    justify-content: space-around;
    margin-bottom: 20px;
  }
  .activity-prize-backgroud .activity-prize-inner .middle-layout img{
    width: 130px;
    height: 130px;
  }
  .activity-prize-backgroud .activity-prize-inner .middle-layout .prize-title{
    text-align: center;
    color: green;
    margin-bottom: 10px;
  }
  .activity-prize-backgroud .activity-prize-inner .bottom-layout{
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .activity-prize-backgroud .activity-prize-inner .bottom-layout img{
    width: 120px;
    height: auto;
    max-width: 100%;
    max-height: 100%; 
  }
  .activity-prize-backgroud .activity-prize-inner .copyright{
    text-align: center;
    font-size: 12px;
    color: #fff;
    z-index: 1;
    position: relative;
    top: 40px;
  }
  .bottom-background-img{
    width: 337px;
    margin: 0 auto;
    position: relative;
    top: -100px;
  }
  .bottom-background-img img{
    width: 100%;
    position: relative;
  }
    .bottom-background-img img{
    width: 100%;
    position: relative;
  }
  .background_left_top {
    position: absolute;
    left: 25px;
    top: 25px;
  }
  .background_left_top img {
    width: 120px;
    height: 40px;
  }
  .background_top_word {
    position: absolute;
    top: 65px;
    left: 35px;
  }
  .background_top_word img {
    width: 300px;
    height: 112px;
  }
  .background_car {
    position: absolute;
    top: 175px;
    left: 105px;
  }
  .background_car img {
    width: 160px;
    height: 120px;
  }
  .rank_tag_main {

  }
  .rank_tag_main img {
    width: 30px;
    height: 24px;
    position: absolute;
    left: 200px;
    top: 90px;
  }
</style>
