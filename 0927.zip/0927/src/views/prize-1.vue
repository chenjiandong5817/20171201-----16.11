<template>
  <img src="./../../static/prize-1.jpeg" style="width:100%;heignt:100%">
</template>
<script>
export default {
  components: {},
  data () {
    return {
    }
  },
  methods: {
  }
}
</script>
