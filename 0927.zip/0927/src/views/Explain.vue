<template>
  <div class="Explain">
    <div class="activity-rule">
      <div class="title" style="margin-left: 80px;width: 195px;">
        <div>元翔专车助力活动规则</div>
      </div>
      <div class="activity-time">
        <div class="green-color">【活动规则】</div>
        <div class="margin-5">
          <span class="green-color">1、</span>
          <span>2018年9月26号——2018年10月7号；</span>
        </div>
        <div class="margin-5">
          <span class="green-color">2、</span>
          <span>本活动每个用户仅可参与一次；</span>
        </div>
        <div class="margin-5">
          <span class="green-color">3、</span>
          <span>每天都可帮不同好友进行助力，每个好友助力一次；</span>
        </div>
        <div class="margin-5">
          <span class="green-color">4、</span>
          <span>助力次数达标后仅可领取一次抵用券(最高领取88元)，抵用券直接发送至活动指定手机号，一个号码仅可领取一次；</span>
        </div>
        <div class="margin-5">
          <span class="green-color">5、</span>
          <span>根据助力排行榜排名，选取前17名用户获得相应名次的奖品（1等奖1名，2等奖2名，3等奖4名，4等奖10名）；</span>
        </div>
        <div class="margin-5">
          <span class="green-color">6、</span>
          <span>另设置特别奖：助力榜尾数带8的用户（排名18—158名），享一次188元无门槛接送机抵用券。</span>
        </div>
      </div>
      <div class="activity-time">
        <div class="green-color">【注意事项】</div>
        <div class="margin-5">
          <span class="green-color">1、</span>
          <span>采用违规行为进行好友助力，一经发现， 取消领奖资格；</span>
        </div>
        <div class="margin-5">
          <span class="green-color">2、</span>
          <span>活动结束后，中奖用户须在48小时内将姓名、联系方式、收货地址发送至微信客服，逾期将取消领奖资格。</span>
        </div>
        <!-- <div class="margin-5">
          <span class="green-color">3、</span>
          <span>本活动最终解释权归本平台所有，详情关注“元翔空港快线”公众号。</span>
        </div> -->
      </div>
    </div>
    <div class="bottom-img"><img src="./../../static/assistance_h5_bottom.png"></div>
  </div>
</template>
<script>
export default {
  components: {},
  data () {
    return {
    }
  },
  methods: {
  }
}
</script>
<style lang="scss">
.Explain{
  width: 100%;
  height: 714px;
  background: white;
  .activity-rule{
    background-color: white;
    border:1px dashed #000;
    border-radius: 8px;
    margin: 10px;
    height: 615px;
    .title{
      height: 35px;
      line-height: 35px;
      text-align: center;
      background: linear-gradient(to right, #1349bc , #0b85ce);
      color: #ffffff;
      font-size: 18px;
      margin: 10px 100px 20px;
      border-radius: 15px;
    }
    .activity-time{
      z-index: 2;
      position: relative;
      text-align: justify;
      word-break: break-all;
      margin: 0px 55px 40px;
      .green-color{
        color: green;
      }
      .margin-5{
        margin: 5px 0px;
      }
    }
  }
  .bottom-img{
    width: 100%;
    position: relative;
    top: -90px;
    img {
      position: relative;
      width: 100%;
      z-index: 1;
      height: 175px;
    }
  }
}
</style>
