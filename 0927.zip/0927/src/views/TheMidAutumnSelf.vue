/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:55:39
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-06-01 10:40:50
 * @Description:  登陆界面
 */
<template>
  <div v-if="loading"></div>
  <div style="overflow-x: hidden;overflow-y: auto;" class="self" v-else>
    <!-- 主页面容器 -->
    <!-- 主背景图片 -->
    <div class="background_main_self">
      <img src="./../../static/background0920_color.png">
    </div>
    <!-- 左上图标 -->
    <div class="background_left_top">
      <img src="./../../static/background_left_top.png">
    </div>
    <!-- 汽车上部文字 -->
    <div class="background_top_word">
      <img src="./../../static/background_top_word.png">
    </div>
    <!-- 汽车图片 -->
    <div class="background_car">
      <img src="./../../static/background_car.png">
    </div>
    <div class="main_panel">
      <!-- 规则按钮 -->
      <el-row class="rule_panel">
        <el-col :span="19" class="rule_button_panel">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="5" class="rule_button_panel">
          <div>
            <el-button size="small" round @click="getRule">活动规则</el-button>
          </div>
        </el-col>
      </el-row>
      <!-- 空白部分，占面积 -->
      <el-row class="blank_panel">
      </el-row>
      <!-- 倒计时部分_小于二十四小时的情况 -->
      <el-row class="time_panel" v-show="isNotLessOneDay">
        <el-col :span="5">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="14">
          <!-- 没有多余的部分，里面显示的就是时间 -->
          <el-row class="time_show_panel">
            <div class="time_word" style="margin-left: 15px;margin-top: 9px;">活动倒计时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">2</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">2</div>
            </div>
            <div class="time_word">时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">3</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">3</div>
            </div>
            <div class="time_word">分</div>
          </el-row>
        </el-col>
        <el-col :span="5">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
      </el-row>
      <!-- 倒计时部分_大于二十四小时的情况 -->
      <el-row class="time_panel" v-show="!isNotLessOneDay">
        <el-col :span="3">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
        <el-col :span="18">
          <!-- 没有多余的部分，里面显示的就是时间 -->
          <el-row class="time_show_panel">
            <div class="time_word" style="margin-left: 15px;margin-top: 9px;">活动倒计时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityDay1 }}</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityDay2 }}</div>
            </div>
            <div class="time_word">天</div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityHour1 }}</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityHour2 }}</div>
            </div>
            <div class="time_word">时</div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityMinute1 }}</div>
            </div>
            <div class="time_number">
              <div style="margin-top: -1px;">{{ activityMinute2 }}</div>
            </div>
            <div class="time_word">分</div>
          </el-row>
        </el-col>
        <el-col :span="3">
          <div style="width: 5px;height: 5px;"></div>
        </el-col>
      </el-row>
      <div>
        <!-- 描述部分 -->
        <div class="background_description">
          <img src="./../../static/self20.png">
        </div>
        <el-row class="rank_panel">
          <el-col :span="2">
            <div style="width: 5px;height: 5px;"></div>
          </el-col>
          <!-- 时间没结束的情况 -->
          <el-col :span="20" class="rank_show_panel" v-show="!isEnd">
             <!-- 进度条 -->
             <div class="progress_panel">
               <!-- 底部 -->
               <div class="progress_bottom">
                <div class="progress_bottom_item" v-for="item in activityRuleDataShow" :key="item.rank">{{ item.assistance }}</div>
               </div>
               <!-- 上部 -->
               <div id="progressTop" class="progress_top">
                <div class="progress_top_item"></div>
               </div>
             </div>
             <!-- 下一个阶梯的次数 -->
             <div class="next_need_time_panel">
               <div>距离下一个折扣还有</div>
               <div class="next_need_time_number">{{ assistanceNeedNumber1 }}</div>
               <div class="next_need_time_number">{{ assistanceNeedNumber2 }}</div>
               <div>次</div>
             </div>
             <!-- 优惠券背景 -->
             <div class="background_account">
               <img src="./../../static/account.png">
             </div>
             <!-- 优惠券 -->
             <div class="account_panel">
               <!-- 钱的显示 -->
               <div class="money_show">
                 <div class="money_sign">¥</div>
                 <div class="money_number">{{ accountMoneyAllow }}</div>
               </div>
               <!-- 领取操作 -->
               <div class="get_money_account">
                 <div @click="getVoucher">
                   <div>点击领取</div>
                   <div>无门槛抵用券</div>
                 </div>
               </div>
             </div>
             <!-- 文字提示获得了多少次 -->
             <div class="word_tip_get">
               已获得助力：
             </div>
             <!-- 已经的次数 -->
             <div class="now_assistance_panel">
               <div class="assistance_getted_number" style="display: inline-block;">{{ assistanceGetted }}</div>
               <div class="assistance_getted_word" style="display: inline-block;">次</div>
             </div>
          </el-col>
          <!-- 时间结束的情况 -->
          <el-col :span="20" class="rank_show_panel" v-show="isEnd">
            <el-row style="position: absolute;top: 20px;left: 100px;font-size: 10px;">
              <div style="display: inline-block;color: #698EAD;">已获得助力：</div>
              <div style="display: inline-block;color: #0d9992;font-size: 75px;">{{ themeObj.assistNum }}</div>
              <div style="display: inline-block;color: #0d9992;font-size: 20px;">次</div>
            </el-row>
            <el-row style="position: absolute;top: 115px;left: 100px;font-size: 10px;">
              <div style="display: inline-block;color: #698EAD;">最终排名：</div>
              <div style="display: inline-block;font-size: 17px;color: #0d9992;">第</div>
              <div style="display: inline-block;font-size: 17px;color: #0d9992;">{{ themeObj.rank }}</div>
              <div style="display: inline-block;font-size: 17px;color: #0d9992;">名</div>
              <div style="display: inline-block"></div>
            </el-row>
            <div class="rank_tag_self" v-show="isShowRankTag">
              <img src="./../../static/rank_tag_0925.png">
            </div>
          </el-col>
          <el-col :span="2">
            <div style="width: 5px;height: 5px;"></div>
          </el-col>
        </el-row>
        <!-- 操作按钮背景图片 -->
        <div class="background_operate_self">
          <img src="./../../static/self21.png">
        </div>
        <!-- 操作按钮部分_从别人的页面进来的情况 -->
        <el-row class="operate_panel">
          <el-col :span="2">
            <div style="width: 5px;height: 5px;"></div>
          </el-col>
          <!-- 按钮图片左边 -->
          <div class="background_button_left">
            <img @click="inviteOther" v-show="!isEnd" src="./../../static/background_button_left.png">
          </div>
          <!-- 按钮图片右边 -->
          <div class="background_button_right">
            <img @click="getMyRank" v-show="!isEnd" src="./../../static/background_button_right.png">
          </div>
          <el-col :span="20" class="operate_show_panel">
            <!-- <div class="operate_left" style="display: none;">
              <el-button type="success" round @click="inviteOther">邀请他人</el-button>
            </div> -->
            <!-- <div class="operate_right" style="display: none;">
              <el-button type="success" round @click="getMyRank">我的排名</el-button>
            </div> -->
          </el-col>
          <el-col :span="2">
            <div style="width: 5px;height: 5px;"></div>
          </el-col>
        </el-row>
      </div>
      <!-- 好友助力操作 -->
      <el-row class="assistance_friend_panel">
         <div class="friend_assistant_0925">
          <img src="./../../static/friend_assistant_0925.png">
        </div>
         <!-- 好友助力蓝色按钮 -->
         <div class="assistance_friend_title">
           <span style="margin-left: 21px;">好友助力</span>
         </div>
         <!-- 横向虚线 -->
         <div class="assistance_friend_dotted"></div>
         <!-- 内容 -->
         <div class="background_friend1">
           <img src="./../../static/background_friend1.png">
         </div>
         <div class="assistance_friend_show_panel" id="assistance_friend_show_panel666">
           <div class="assistance_friend_show" v-for="item in friendsList">
             <!-- 头像 -->
             <div class="head_img_panel">
               <!-- 头像 -->
                <img class="head_img" :src="item.avatar">
             </div>
             <!-- 姓名日期 -->
             <div class="name_date_panel">
               <!-- 姓名 -->
               <div style="margin-bottom: 4px;font-size: 13px;">{{ item.nickname }}</div>
               <!-- 日期 -->
               <div style="font-size: 13px;">{{ setDateFormat(item.createTime) }}</div>
             </div>
             <!-- 按钮 -->
             <div class="assistance_button_panel">
               <!-- 按钮 -->
               <div>助力</div>
               <!-- <el-button :disabled="disabledAssistance" size="medium">助力</el-button> -->
             </div>
           </div>
         </div>
         <!-- 滑动查看 -->
         <div class="assistance_friend_get_more"></div>
      </el-row>
      <div class="activity-prize-backgroud">
        <div class="activity-prize-inner">
          <div class="title">
            <div class="title-font-prize">活动奖品</div>
            <img src="./../../static/assistance_h5_title.png">
          </div>

          <div class="middle-layout">
            <div @click="$router.push({ path: '/PrizeOne' })">
              <div class="prize-title">一等奖 (第1名)</div>
              <img src="./../../static/one_prize.png">
              <div style="width:130px">厦门佰翔五通酒店豪华海景房+自助晚餐券 (1名)</div>
            </div>
            <div @click="$router.push({ path: '/PrizeTwoThree' })">
              <div class="prize-title">二等奖 (第2~3名)</div>
              <img src="./../../static/two_prize.png">
              <div style="width:130px">福州佰翔空港花园酒店尊品房+自助午餐券 (2名)</div>
            </div>
          </div>

          <div class="middle-layout">
            <div @click="$router.push({ path: '/PrizeTwoThree' })">
              <div class="prize-title">三等奖 (第4~7名)</div>
              <img src="./../../static/three_prize.png">
              <div style="width:130px">福州佰翔空港花园酒店花园房+自助午餐券 (4名)</div>
            </div>
            <div onclick="window.open('http://t.cn/EvSQWyY','_self')">
              <div class="prize-title">四等奖 (第8~17名)</div>
              <img src="./../../static/four_prize.png">
              <div style="width:130px">佰翔手礼网三星报喜敢当茶礼盒 (10名)</div>
            </div>
          </div>

          <div class="middle-layout">
            <div style="text-align: center">
              <div class="prize-title">特别奖(18-158名排名尾号带“8”的)</div>
              <img src="./../../static/special_prize.png">
              <div style="width:200px;">元翔专车福州/厦门地区无门槛 188送机券一张(15名)</div>
            </div>
          </div>

          <div class="title" style="position: relative">
            <div class="title-font-sponsor">活动赞助商</div>
            <img src="./../../static/assistance_h5_title.png">
          </div>

          <div class="bottom-layout">
            <div>
              <img src="./../../static/sponsor-1.png">
            </div>
            <div>
              <img src="./../../static/sponsor-2.png">
            </div>
          </div>
          <div class="bottom-layout">
            <div>
              <img src="./../../static/sponsor-3.png">
            </div>
            <div>
              <img src="./../../static/sponsor-4.png">
            </div>
          </div>

          <div class="copyright">
            <div>活动主办方：元翔空港快线</div>
            <div>本次活动技术支持：厦门兆翔科技</div>
          </div>
        </div>
      </div>
      <div class="bottom-background-img"><img src="./../../static/assistance_h5_bottom.png"></div>
    </div>
    <!-- 领取抵用券的弹出框 -->
    <div class="voucher_dialog_visiable">
      <el-dialog
        title=""
        :visible.sync="voucherDialogVisiable"
        width="30%"
        center
        @close="closeVouche">
        <div class="get_account_background">
          <img src="./../../static/get_account_background2.png">
        </div>
        <!-- 弹出框的虚线范围 -->
        <div class="dotted_line_panel">
          <!-- 提示语 -->
          <div class="tip_word1">抵用券仅可领用1次</div>
          <div class="tip_word2">领取后仍可继续参加助力排名活动</div>
          <!-- 输入框 -->
          <div class="input_panel">
            <div class="input_tip">手机：</div>
            <div class="input_telephone">
              <el-input v-model="accountForm.telephone" placeholder="请输入获抵用券的手机号码"></el-input>
            </div>
          </div>
          <!-- 单选按钮 -->
          <div class="radio_panel">
             <el-radio v-model="accountForm.area" label="2">福州机场</el-radio>
             <el-radio v-model="accountForm.area" label="1">厦门机场</el-radio>
          </div>
          <div class="button_panel" style="position: relative;">
            <el-button @click="submitTelephone">确定</el-button>
          </div>
        </div>
      </el-dialog>
    </div>
    <!-- 邀请他人 -->
    <div v-show="isNotInviteShow" class="invite_other_panel" @click="clickInviteShow">
      <!-- 邀请他人的箭头 -->
      <div class="background_icon">
        <img src="./../../static/new_direction_share.png">
      </div>
      <div class="invite_other_word_top"><div style="display: inline-block;color: #3C3CD4;">“</div><div style="display: inline-block;">分享给好友</div></div>
      <div class="invite_other_word_bottom"><div style="display: inline-block;">获得更多助力</div><div style="display: inline-block;color: #3C3CD4;">,,</div></div>
    </div>
    <!-- 我的排名弹出框 -->
    <div class="my_rank_dialog">
      <el-dialog
        title=""
        :visible.sync="myRankVisiable"
        width="30%">
        <!-- 助力排行榜主的背景图片 -->
        <div class="background_main_friend">
          <img src="./../../static/background_other_bottom.png">
        </div>
        <!-- 助力排行榜副的背景图片 -->
        <div class="background_other_friend">
          <img src="./../../static/background_friend2.png">
        </div>
        <!-- 容器 -->
        <div class="my_rank_panel">
          <!-- 标题 -->
          <div class="my_rank_title">
            <span style="margin-left: 0">助力排行榜</span>
          </div>
          <!-- 虚线 -->
          <div class="my_rank_dotted"></div>
          <!-- 排行榜 -->
          <div class="my_rank_rank">
            <div style="position: absolute;left: 75px;top: 85px;">当前排行：</div>
            <div style="width: 10px;height: 15px;border: 1px solid #2ef52e;position: absolute;top: 85px;left: 145px;">{{ nowRank1 }}</div>
            <div style="width: 10px;height: 15px;border: 1px solid #2ef52e;position: absolute;top: 85px;left: 165px;">{{ nowRank2 }}</div>
            <div style="width: 10px;height: 15px;border: 1px solid #2ef52e;position: absolute;top: 85px;left: 185px;">{{ nowRank3 }}</div>
            <div style="width: 10px;height: 15px;border: 1px solid #2ef52e;position: absolute;top: 85px;left: 205px;">{{ nowRank4 }}</div>
            <div style="width: 10px;height: 15px;position: absolute;top: 85px;left: 225px;">名</div>
          </div>
          <!-- 内容 -->
          <div class="my_rank_content">
            <!-- 表头 -->
            <div class="table_head">
              <div style="display: inline-block;">排行</div>
              <div style="display: inline-block;margin-left: 20px;">头像</div>
              <div style="display: inline-block;margin-left: 30px;">昵称</div>
              <div style="display: inline-block;margin-left: 20px;">助力数</div>
            </div>
            <!-- 内容 -->
            <div id="table_content_panel666" class="table_content_panel">
              <!-- <div style="width: 50px;height: 1500px;"></div> -->
              <div class="table_content_item" v-for="item in rankDatas">
                <div style="display: inline-block;width: 18%;text-align: right;vertical-align: top;margin-top: 10px;">{{ item.rank }}</div>
                <div style="display: inline-block;width: 28%;text-align:  right;">
                  <div class="img_rank_head_one_two_three">
                    <!-- <img class="img_rank_head_one_two_three_img" src=""> -->
                  </div>
                  <img class="img_rank_head" :src="item.createrAvatar">
                </div>
                <div style="display: inline-block;width: 20%;text-align: right;vertical-align:  top;margin-top: 5px;">{{ item.createrNickname }}</div>
                <div style="display: inline-block;width: 15%;text-align: right;vertical-align:  top;margin-top: 7px;">{{ item.assistNum }}</div>
              </div>
            </div>
          </div>
          <!-- 滑动操作 -->
          <div class="my_rank_operate"></div>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
  import globalData from './../common/config/global'
  import util from './../common/js/util'
  import API from './../api'
  import $ from 'jquery'
  export default {
    data () {
      return {
        // 是否是一天之内
        isNotLessOneDay: false,
        // 活动倒计时的天
        activityDay1: null,
        activityDay2: null,
        // 活动倒计时的小时
        activityHour1: null,
        activityHour2: null,
        // 活动倒计时的分
        activityMinute1: null,
        activityMinute2: null,
        // 已经获得的助力的次数
        assistanceGetted: null,
        // 助力需要的次数
        assistanceNeedNumber1: null,
        assistanceNeedNumber2: null,
        // 活动规则的数据用于显示在页面上的
        activityRuleDataShow: null,
        // 已经可以拿到的优惠券的钱
        accountMoneyAllow: null,
        // 抵用券弹出框的是否显示
        voucherDialogVisiable: false,
        // 优惠券获取的表单
        accountForm: {
          telephone: null,
          area: '2'
        },
        // 是否要显示邀请人助力的图片
        isNotInviteShow: false,
        // 朋友列表数据
        friendsList: null,
        // 我的排名是否弹出
        myRankVisiable: false,
        // 排行榜的数据
        rankDatas: null,
        // 助力排行榜的页码
        asisstanceRankPage: 1,
        // 好友列表的页码
        friendHelpListPage: 1,
        // 自己的themeId
        selfThemeId: null,
        // 创建主题后的数据
        themeObj: {},
        disabledAssistance: true,
        // 是否结束
        isEnd: false,
        // 当前排行：
        nowRank1: null,
        nowRank2: null,
        nowRank3: null,
        nowRank4: null,
        rankpage: 1,
        rankCache: [],
        friendpage: 1,
        friendCache: [],
        isNotWxConfigSuccess: null,
        loading: false,
        isShowRankTag: false
      }
    },
    methods: {
      // 获得规则详情
      getRule () {
        this.$router.push({ path: '/Explain' })
      },
      // 获得活动的剩余时间
      getActivityTime (days, hours, minutes) {
        var day = String(days)
        var hour = String(hours)
        var minute = String(minutes)
        // 天的情况
        if (day.length === 1) {
          this.activityDay1 = '0'
          this.activityDay2 = day
        }
        if (day.length === 2) {
          this.activityDay1 = day[0]
          this.activityDay2 = day[1]
        }
        // 小时的情况
        if (hour.length === 1) {
          this.activityHour1 = '0'
          this.activityHour2 = hour
        }
        if (hour.length === 2) {
          this.activityHour1 = hour[0]
          this.activityHour2 = hour[1]
        }
        // 分钟的情况
        if (minute.length === 1) {
          this.activityMinute1 = '0'
          this.activityMinute2 = minute
        }
        if (minute.length === 2) {
          this.activityMinute1 = minute[0]
          this.activityMinute2 = minute[1]
        }
      },
      getConditionInfo (assistanceNum) {
        // 获得他现在的次数
        var nowTimes = assistanceNum
        // 距离下一个阶梯还有多少次
        var nextRankNeedTime = null
        // 获取活动规则数据
        var activityRuleData = globalData.ACTIVITYRULEDATA
        // 设置页面显示的数据
        this.activityRuleDataShow = util.deepCopy(activityRuleData)
        this.activityRuleDataShow.pop()
        var ruleDataOne = { rank: 10, assistance: '88+', money: '88+' }
        this.activityRuleDataShow.push(ruleDataOne)
        // 计算距离下一个折扣还要助力多少次
        for (var i = 0; i < activityRuleData.length; i++) {
          if ((nowTimes > activityRuleData[i].assistance || nowTimes === activityRuleData[i].assistance) && nowTimes < activityRuleData[i + 1].assistance) {
            if (nowTimes > 88) {
              // 设置进度条的长度
              var progressTop4 = document.getElementById('progressTop')
              progressTop4.style.width = '260px'
              // 获得当前还需要的次数
              nextRankNeedTime = '0'
              // 已经有的优惠券的钱
              this.accountMoneyAllow = 88
            } else {
              // 设置进度条的长度
              var progressTop = document.getElementById('progressTop')
              var progressTopWidth = (activityRuleData[i].rank * 26 - 10).toString()
              progressTop.style.width = progressTopWidth + 'px'
              // 获得当前还需要的次数
              nextRankNeedTime = (activityRuleData[i + 1].assistance - nowTimes).toString()
              // 已经有的优惠券的钱
              this.accountMoneyAllow = activityRuleData[i].money
            }
          }
          if (nowTimes > 0 && nowTimes < 8) {
            // 设置进度条的长度
            var progressTop1 = document.getElementById('progressTop')
            progressTop1.style.width = '18px'
            // 获得当前还需要的次数
            nextRankNeedTime = (8 - nowTimes).toString()
            // 已经有的优惠券的钱
            this.accountMoneyAllow = 0
          }
          if (nowTimes === 0) {
            // 设置进度条的长度
            var progressTop2 = document.getElementById('progressTop')
            progressTop2.style.width = '0px'
            // 获得当前还需要的次数
            nextRankNeedTime = (8 - nowTimes).toString()
            // 已经有的优惠券的钱
            this.accountMoneyAllow = 0
          }
        }
        // 自己已经获得的次数
        this.assistanceGetted = nowTimes
        // 别人需要次数的情况
        if (nextRankNeedTime.length === 1) {
          this.assistanceNeedNumber1 = '0'
          this.assistanceNeedNumber2 = nextRankNeedTime
        }
        if (nextRankNeedTime.length === 2) {
          this.assistanceNeedNumber1 = nextRankNeedTime[0]
          this.assistanceNeedNumber2 = nextRankNeedTime[1]
        }
      },
      // 邀请他人助力的钩子
      inviteOther () {
        this.isNotInviteShow = true
        // 发送相关数据给后端，后端返回给我
      },
      // 点击帮人助力页面的钩子
      clickInviteShow () {
        this.isNotInviteShow = false
      },
      // 我也要助力的钩子
      getMyRank () {
        this.myRankVisiable = true
        var rankTostring = String(this.themeObj.rank)
        if (rankTostring.length === 1) {
          this.nowRank1 = 0
          this.nowRank2 = 0
          this.nowRank3 = 0
          this.nowRank4 = rankTostring[0]
        }
        if (rankTostring.length === 2) {
          this.nowRank1 = 0
          this.nowRank2 = 0
          this.nowRank3 = rankTostring[0]
          this.nowRank4 = rankTostring[1]
        }
        if (rankTostring.length === 3) {
          this.nowRank1 = 0
          this.nowRank2 = rankTostring[0]
          this.nowRank3 = rankTostring[1]
          this.nowRank4 = rankTostring[2]
        }
        if (rankTostring.length === 4) {
          this.nowRank1 = rankTostring[0]
          this.nowRank2 = rankTostring[1]
          this.nowRank3 = rankTostring[2]
          this.nowRank4 = rankTostring[3]
        }
        // 获取图片头像
        this.$nextTick(() => {
          this.scrollLoadRank()
        })
        this.rankpage = 1
        this.rankCache = []
        // 获取数据
        this.getRankRequest()
        // 跳转到另外一个地址
      },
      // 请求数据
      getRankRequest () {
        API.getAllAsisstanceRank().go(this.rankpage).then((data) => {
          if (data.status === 1) {
            for (var c = 0; c < data.list.length; c++) {
              this.rankCache.push(data.list[c])
            }
            // 自己的
            var selfRank = []
            // 不是自己的
            var selfOthers = []
            for (var i = 0; i < this.rankCache.length; i++) {
              if (this.themeObj.createrUserId !== this.rankCache[i].createrUserId) {
                selfOthers.push(this.rankCache[i])
              }
              if (this.themeObj.createrUserId === this.rankCache[i].createrUserId) {
                selfRank.push(this.rankCache[i])
              }
            }
            var result = selfOthers.slice(0, this.themeObj.rank - 1).concat(selfRank).concat(selfOthers.slice(this.themeObj.rank - 1, selfOthers.length))
            this.rankDatas = result
            for (var a = 0; a < this.rankDatas.length; a++) {
              this.rankDatas[a]['rank'] = a + 1
            }
          }
          if (data.status === -2) {
            window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
          }
        })
      },
      // 领取抵用券的操作--------------------------------start
      getVoucher () {
        this.voucherDialogVisiable = true
      },
      // 确定领取优惠券
      submitTelephone () {
        var params = {
          areaId: this.accountForm.area,
          mobile: this.accountForm.telephone,
          themeId: this.themeObj.themeId
        }
        // console.log('params', params)
        API.getCouponSelf().go(params).then((data) => {
          if (data.status === 1) {
            alert(data.message)
          }
          if (data.status === -2) {
            window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
          }
          if (data.status === -1) {
            alert(data.message)
          }
        })
        this.voucherDialogVisiable = false
      },
      // 关闭优惠券弹出框
      closeVouche () {
        this.telephone = null
      },
      // --------------------------------------------------end
      // 获取好友列表
      getFriendsList () {
        var themeId = this.themeObj.themeId
        API.getFriendHelpList(themeId, this.friendpage).go().then((data) => {
          if (data.status === 1) {
            for (var i = 0; i < data.list.length; i++) {
              this.friendCache.push(data.list[i])
            }
            this.friendsList = this.friendCache
          }
          if (data.status === -2) {
            window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
          }
        })
      },
      // 这边下周做。token的获取放到localStorage中。一进来就只调用那两个方法。要是有
      // 方法返回token失效就跳转那个地址
      getIntoWx () {
        this.$nextTick(() => {
          this.scrollLoadFriend()
        })
        this.createTheme()
        // window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
      },
      // 创建主题
      createTheme () {
        API.createTheme().go().then((data) => {
          if (data.status === 1) {
            this.themeObj = Object.assign({}, data.data)
            // 排名皇冠------start
            if (this.themeObj.rank === 1 || this.themeObj.rank === 2 || this.themeObj.rank === 3) {
              this.isShowRankTag = true
            }
            // ----------------end
            this.wxShareOperate()
            this.wxShareFriend()
            // 获取剩余的秒数
            var leftMinutes = parseInt((parseInt(this.themeObj.endTime) - parseInt((new Date()).valueOf())) / 1000 / 60)
            // 给定时器传结束的时间
            this.getTimer(leftMinutes)
            // 在页面上描述出相关信息
            this.getConditionInfo(this.themeObj.assistNum)
            // 获取好友列表
            this.getFriendsList()
          }
          if (data.status === -2) {
            window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
          }
          if (data.status === -1) {
            alert(data.message + ',请重新刷新页面！')
          }
        })
      },
      // 设置定时器
      getTimer (leftMinutes) {
        var minutes = null
        var hours = null
        var days = null
        // 获得天数
        days = parseInt(leftMinutes / (60 * 24))
        // 获得小时数
        hours = parseInt(parseInt(leftMinutes % (60 * 24)) / 60)
        // 获得分钟数
        minutes = parseInt((leftMinutes % (60 * 24)) % 60)
        // 先赋值
        this.getActivityTime(days, hours, minutes)
        var _this = this
        var timer = setInterval(function () {
            minutes = minutes - 1
            if (minutes < 0) {
              minutes = 59
              hours = hours - 1
            }
            if (hours < 0) {
              hours = 23
              days = days - 1
            }
            // 每分钟赋值一次
            _this.getActivityTime(days, hours, minutes)
            if (leftMinutes === 0 || leftMinutes < 0) {
              minutes = 0
              hours = 0
              days = 0
              this.isEnd = true
              clearInterval(timer)
            }
        }, 60 * 1000)
        if (leftMinutes === 0 || leftMinutes < 0) {
          minutes = 0
          hours = 0
          days = 0
          this.getActivityTime(days, hours, minutes)
          this.isEnd = true
          clearInterval(timer)
        }
      },
      // 获取个人信息
      getUserInfo () {
        API.getUserInfo().go().then((data) => {
          if (data.status === 1) {
            // console.log(data)
          }
        })
      },
      // 获取所有助力排行
      getAllAsisstanceRank () {
        var page = this.asisstanceRankPage
        API.getAllAsisstanceRank().go(page).then((data) => {
          if (data.status === 1) {
            // console.log(data)
          }
        })
      },
      // 获取微信配置
      getWXConfigShare () {
        // console.log('location.href', location.href)
        // let _this = this
        return new Promise(resolve => {
          // 做一个判断对路径
          API.getWXJSDK().go({url: encodeURIComponent(location.href)}).then((data) => {
            if (data.status === 1) {
              this.wx.config({
                debug: false,
                appId: data.data.appId,
                timestamp: data.data.timestamp,
                nonceStr: data.data.nonceStr,
                signature: data.data.signature,
                jsApiList: ['onMenuShareAppMessage', 'onMenuShareTimeline']
              })
              this.wx.error(function (res) {
                // alert(res.errMsg)
                if (res.errMsg.indexOf('invalid')) {
                  // window.location.href = 'http://yxzq.yxzc01.com/midautumn/auth/do'
                }
              })
              this.wx.ready(function () {
                resolve()
              })
            }
          })
        })
      },
      // 转换时间格式yyyy-mm-dd HH:mm:ss
      setDateFormat (value) {
        if (value === '') {
          return ''
        } else {
          let moment = require('moment')
          let dateFormat = moment(value).format('YYYY-MM-DD HH:mm:ss')
          return dateFormat
        }
      },
      // 滚动加载
      scrollLoadRank () {
        var _this = this
        var rankPanelDom = $('#table_content_panel666')
        rankPanelDom.scroll(function () {
          var viewH = rankPanelDom.height()
          var contentH = rankPanelDom.get(0).scrollHeight
          var scrollTop = rankPanelDom.scrollTop()
          // console.log(contentH - viewH - scrollTop)
          if (contentH - viewH - scrollTop === 0) {
            // console.log('rank')
            _this.rankpage = _this.rankpage + 1
            _this.getRankRequest()
          }
        })
      },
      // 滚动加载
      scrollLoadFriend () {
        var _this = this
        var friendPanelDom = $('#assistance_friend_show_panel666')
        friendPanelDom.scroll(function () {
          var viewH = friendPanelDom.height()
          var contentH = friendPanelDom.get(0).scrollHeight
          var scrollTop = friendPanelDom.scrollTop()
          // console.log(contentH - viewH - scrollTop)
          if (contentH - viewH - scrollTop === 0) {
            // console.log('friend')
            _this.friendpage = _this.friendpage + 1
            _this.getFriendsList()
          }
        })
      },
      repeatConfig () {
        this.loading = true
        this.getWXConfigShare().then(() => {
          this.loading = false
          this.$nextTick(() => {
            this.getIntoWx()
          })
        })
      },
      reSetAlert () {
        window.alert = function (name) {
          var iframe = document.createElement('IFRAME')
          iframe.style.display = 'none'
          iframe.setAttribute('src', 'data:text/plain,')
          document.documentElement.appendChild(iframe)
          window.frames[0].window.alert(name)
          iframe.parentNode.removeChild(iframe)
        }
      },
      wxShareOperate () {
        let _this = this
        this.wx.onMenuShareAppMessage({
          title: '重要通知：您有一张88元无门槛接送机抵用券等待领取', // 分享标题
          desc: '元翔专车邀你助力，获88元无门槛接送机抵用券，还有价值2688元豪华海景酒店+自助餐等您领取', // 分享描述
          link: location.href.split('#')[0] + '#/TheMidAutumnMain?themeId=' + _this.themeObj.themeId,
          imgUrl: 'http://yxzq.yxzc01.com/static/share_img_link.png', // 分享图标
          success: function () {
            console.log(location.href.split('?from=singlemessage&isappinstalled=0#')[0] + '#/TheMidAutumnMain?themeId=' + _this.themeObj.themeId)
            // 用户确认分享后执行的回调函数
          },
          error: function () {
            alert('请重新刷新页面！')
          },
          cancel: function () {
            // 用户取消分享后执行的回调函数
          }
        })
      },
      wxShareFriend () {
        let _this = this
        console.log('this.wx', this.wx)
        this.wx.onMenuShareTimeline({
          title: '重要通知：您有一张88元无门槛接送机抵用券等待领取',
          link: location.href.split('#')[0] + '#/TheMidAutumnMain?themeId=' + _this.themeObj.themeId,
          imgUrl: 'http://yxzq.yxzc01.com/static/share_img_link.png',
          success: function () {
            console.log(location.href.split('?from=singlemessage&isappinstalled=0#')[0] + '#/TheMidAutumnMain?themeId=' + _this.themeObj.themeId)
          },
          cancel: function () {
            console.log(3)
          }
        })
      }
    },
    mounted () {
      this.reSetAlert()
      // 加载微信配置后，加载用户数据
      this.repeatConfig()
    }
  }
</script>

<style>
  .self .main_panel {
    /* 隐藏内部滚动条 ptk*/
    overflow: hidden;
    /* 扩大高度 ptk*/
    height: 1945px; 
    width: 100%;
    z-index: 10;
    background-color: white;
    position: static;
  }
  .self .rule_panel {
    height: 100px;
  }
  .self .blank_panel {
    height: 200px;
  }
  .self .time_panel {
    height: 50px;
  }
  .self .rank_panel {
    height: 160px;
    z-index: 10;
  }
  .self .operate_panel {
    height: 100px;
    z-index: 10;
  }
  .self .assistance_friend_panel {
    position: static;
  	height: 300px;
  }
  /*设置规则按钮*/
  .self .rule_button_panel .el-button--small {
    border-radius: 20px!important;
    background-color: black;
    color: white!important;
    opacity: 0.3;
  }
  .self .rule_button_panel {
    margin-top: 20px;
  }
  .self .time_show_panel {
    margin-top: 10px;
    height: 40px;
    background-color: #0563ea;
    border-radius: 10px 10px 0 0;
  }
  .self .time_word {
    display: inline-block;
    font-size: 15px;
    color: white;
  }
  .self .time_number {
    display: inline-block;
    width: 15px;
    height: 23px;
    font-size: 23px;
    color: black;
    background-color: white;
  }
  .self .rank_show_panel {
  	height: 160px;
    position: static;
  }
  .self .operate_show_panel {
    height: 100px;
    position: static;
  }
  .self .operate_left {
    display: inline-block;
    position: absolute;
    top: 50px;
    left: 45px;
  }
  .self .operate_right {
    display: inline-block;
    position: absolute;
    top: 50px;
    left: 195px;
  }
  .self .operate_direct {
    display: inline-block;
    position: absolute;
    top: 25px;
    left: 140px;
  }
  .self .operate_left .el-button {
    background-color: #ffea4f;
    border-radius: 20px;
    width: 130px;
    height: 40px;
  }
  .self .operate_right .el-button {
    background-color: #ffea4f;
    border-radius: 20px;
    width: 130px;
    height: 40px;
  }
  .self .operate_direct .el-button {
    background-color: #cccc2b;
    border-radius: 20px;
    height: 40px;
  }
  /*进度条*/
  .self .progress_panel {
  	width: 280px;
    height: 20px;
    background-color: white;
    position: absolute;
    left: 47px;
    top: 15px;
    border-radius: 10px;
  }
  .self .progress_bottom_item {
  	display: inline-block;
  	width: 25px;
  	height: 20px;
  	margin-left: 2.2px;
  	background-color: #d7dee2;
  	color: white;font-size: 18px;
  }
  .self .progress_bottom div:last-child {
  	border-top-right-radius: 10px;
  	border-bottom-right-radius: 10px;
    width: 28px!important;
  }
  .self .progress_bottom div:first-child {
  	margin-left: 0px!important;
  	border-top-left-radius: 10px;
  	border-bottom-left-radius: 10px;
    width: 28px!important;
  }
  .self .progress_bottom {
  	position: absolute;
  	z-index: 88;
  }
  .self .progress_top {
  	position: absolute;
    z-index: 88;
  	width: 131px;
    height: 20px;
    background-color: #1919b9;
    background: linear-gradient(left,#1535b6,#0c7fcc);
    border-radius: 10px;
  }
  /*距离折扣次数*/
  .self .next_need_time_panel {
    position: absolute;
    top: 40px;
    left: 50px;
    width: 180px;
    height: 20px;
    background-color: white;
  }
  .self .next_need_time_panel div {
    display: inline-block;
  }
  .self .next_need_time_number {
    width: 10px;
    height: 15px;
    border: solid 1px green;
  }
  /*优惠券操作的容器*/
  .self .account_panel {
    position: absolute;
    left: 250px;
    top: 50px;
    width: 80px;
    height: 80px;
  }
  .self .money_show {
    text-align: center;
    width: 80%;
    height: 50px;
    margin-left: 0;
  }
  .self .money_sign {
    display: inline-block;
    margin-left: 5px;
    margin-top: 13px;
    color: white;
    font-size: 20px;
  }
  .self .money_number {
    display: inline-block;
    color: white;
    font-size: 30px;
    margin-right: 5px;
  }
  .self .get_money_account {
    margin-left: 0;
    margin-top: 0;
    border-radius: 20px;
    width: 75px;
    text-align: center;
    color: #3491c5;
    font-size: 10px;
    font-weight: 500;
  }
  /*自己被助力的次数*/
  .self .now_assistance_panel {
    text-align: center;
    position: absolute;
    left: 140px;
    top: 70px;
    width: 120px;
    height: 100px;
  }
  .self .assistance_getted_number {
    display: inline-block;
    margin-left: 5px;
    margin-top: 0;
    font-size: 75px;
    color: #0d9992;
  }
  .self .assistance_getted_word {
    display: inline-block;
    color: #0d9992;
    margin-right: 10px;
  }
  /*抵用券弹出框*/
  .self .voucher_dialog_visiable .el-dialog {
    top: 30%!important;
    width: 80%!important;
  }
  /*抵用券弹出框的关闭按钮*/
  .self .voucher_dialog_visiable .el-dialog__headerbtn {
    position: absolute!important;
    right: -15px!important;
    top: -15px!important;
    background-color: black!important;
    opacity: 0.3!important;
    border-radius: 30px!important;
    width: 30px!important;
    height: 30px!important;
  }
  .self .voucher_dialog_visiable .el-dialog__body {
    padding: 0!important;
  }
  .self .voucher_dialog_visiable .dotted_line_panel {
    width: 270px;
    height: 230px;
    margin-left: 15px;
    margin-bottom: 15px;
    border: 1px dotted black;
    position: static;
    text-align: center;
  }
  .self .voucher_dialog_visiable .tip_word1 {
    margin-top: 10px;
  }
  .self .voucher_dialog_visiable .tip_word2 {
    margin-top: 5px;
  }
  .self .voucher_dialog_visiable .input_panel {
    margin-top: 15px;
  }
  .self .voucher_dialog_visiable .input_panel .input_tip{
    width: 18%;
    display: inline-block;
  }
  .self .voucher_dialog_visiable .input_panel .input_telephone{
    width: 75%;
    display: inline-block;
  }
  .input_panel .el-input__inner {
    border-radius: 50px;
  }
  .voucher_dialog_visiable .radio_panel {
    margin-top: 15px;
  }
  .self .voucher_dialog_visiable .button_panel {
    margin-top: 50px;
  }
  .self .voucher_dialog_visiable .button_panel .el-button {
    width: 150px;
    background-color: #ffea4f;
    border-radius: 50px;
  }
  /*邀请他人的弹出页面*/
  .self .invite_other_panel {
    position: absolute;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 1945px;
    background-color: black;
    opacity: 0.6;
    z-index: 230;
  }
  .self .invite_other_word_top {
    position: fixed;
    top: 70px;
    left: 100px;
    color: white;
    font-size: 25px;
  }
  .self .invite_other_word_bottom {
    white-space: pre;
    position: fixed;
    color: white;
    top: 110px;
    left: 165px;
    font-size: 23px;
  }
  /*好友助力本页面区域*/
  .self .assistance_friend_panel .assistance_friend_title {
    width: 32%;
    font-size: 20px;
    color: white;
    border-radius: 33px;
    margin-left: 125px;
    margin-top: 32px;
    z-index: 180;
    height: 30px;
    position: sticky;
    position: relative;
  }
  .self .assistance_friend_panel .assistance_friend_dotted {
    display: none;
    position: absolute;
    top: 652px;
    width: 78%;
    z-index: 50;
    left: 40px;
    border-top-color: #BBB9B9;
    border-top-style: dashed;
    border-top-width: 1px;
    border-image-source: initial;
    border-image-slice: initial;
    border-image-width: initial;
    border-image-outset: initial;
    border-image-repeat: initial;
  }
  .self .assistance_friend_show_panel {
    max-height: 140px!important;
    overflow-x: hidden;
    overflow-y: auto;
    z-index: 10;
    position: sticky;
    margin-top: 10px;
    position: relative;
  }
  .self .assistance_friend_panel .assistance_friend_show {
    width: 100%;
    height: 50px;
  }
  .self .assistance_friend_panel .assistance_friend_show .head_img_panel {
    display: inline-block;
    margin-top: 10px;
    margin-left: 40px;
  }
  .self .assistance_friend_panel .assistance_friend_show .head_img {
    width: 35px;
    height: 35px;
    border-radius: 35px;
  }
  .self .assistance_friend_panel .assistance_friend_show .name_date_panel {
    margin-left: 15px;
    display: inline-block;
  }
  .self .assistance_button_panel {
    display: inline-block;
    margin-left: 50px;
    vertical-align: top;
    margin-top: 20px;
  }
  .self .assistance_button_panel div {
    background-color: #7ccbc5;
    color: white;
    border-radius: 30px;
    width: 50px;
    height: 22px;
    text-align: center;
  }
  /*我的排名弹出框*/
  .my_rank_dialog .el-dialog {
    width: 80%;
  }
  .my_rank_dialog .el-dialog__body {
    padding: 0!important;
  }
  .my_rank_dialog .my_rank_panel {
    width: 250px;
    height: 430px;
    background-color: wheat;
    margin-left: 28px;
    margin-bottom: 30px;
    margin-top: 15px;
    position: static;
    text-align: center;
  }
  .self .my_rank_dialog .el-dialog__headerbtn {
    position: absolute!important;
    right: -15px!important;
    top: -15px!important;
    background-color: black!important;
    opacity: 0.3!important;
    border-radius: 30px!important;
    width: 30px!important;
    height: 30px!important;
    z-index: 100!important;
  }
  .my_rank_title {
    background-color: #4545e0;
    width: 55%;
    color: white;
    font-size: 25px;
    border-radius: 30px;
    position: absolute;
    left: 70px;
    top: 35px;
    z-index: 200;
    text-align: center;
  }
  .my_rank_dotted {
    position: absolute;
    width: 80%;
    top: 50px;
    z-index: 100;
    left: 33px;
    border-top-color: #BBB9B9;
    border-top-style: dashed;
    border-top-width: 1px;
    border-image-source: initial;
    border-image-slice: initial;
    border-image-width: initial;
    border-image-outset: initial;
    border-image-repeat: initial;
  }
  .my_rank_rank {

  }
  .my_rank_content {
    width: 88%;
    height: 300px;
    position: absolute;
    left: 25px;
    top: 105px;
    text-align: center;
  }
  .table_head {
    margin-top: 10px;
  }
  .table_content_panel {
    margin-top: 10px;
    max-height: 240px;
    overflow-x: hidden;
    overflow-y: auto;
  }
  .table_content_item {
    margin-top: 5px;
    text-align: left;
  }
  .img_rank_head {
    width: 40px;
    height: 40px;
    border-radius: 40px;
  }
  .my_rank_operate {

  }
  .self .background_main_self img {
    position: absolute!important;
    width: 100%!important;
    height: 1945px!important;
  }
  .self .background_description img {
    position: absolute;
    top: 340px;
    left: 19px;
    z-index: 5;
  }
  .self .background_account img {
    position: absolute;
    top: 48px;
    left: 251px;
    width: 70px;
    height: 45px;
  }
  .self .background_operate_self img {
    position: absolute;
    top: 566px;
    left: 19px;
  }
  .self .background_friend1 img {
    position: absolute;
    width: 360px;
    height: 280px;
    top: 623px;
    z-index: 10;
    left: 7px;
  }
  .self .background_icon img {
    position: fixed;
    z-index: 120;
    width: 60px;
    height: 70px;
    left: 290px;
  }
  .self .background_other_friend img {
    position: absolute;
    width: 100%;
    height: 460px;
    top: 20px;
    left: 5px;
  }
  .self .background_main_friend img {
    position: absolute;
    top: 0;
    width: 100%;
    height: 495px;
  }
  .word_tip_get {
    position: absolute;
    top: 125px;
    left: 70px;
    color: #31bcaf;
    font-size: 13px;
  }
  .get_account_background img {
    width: 300px;
    position: absolute;
    bottom: 0px;
    height: 125px;
  }
  .table_content_panel .img_rank_head_one_two_three:first-child img {
  }
  .table_content_panel .img_rank_head_one_two_three:nth-child(2) img {
  }
  .table_content_panel .img_rank_head_one_two_three:nth-child(3) img {
  }
  .activity-prize-backgroud {
    position: relative;
    background: linear-gradient(to right, #0e6ec7 , #1347bb);
    width: 337px;
    margin: 0 auto;
    padding: 10px;
    box-sizing: border-box;
    height: 1030px;
  }
  .activity-prize-backgroud .activity-prize-inner{
    background-color: #fff;
    height: 100%;
  }
  .activity-prize-backgroud .activity-prize-inner .title img{
    width: 100%;
  }
  .activity-prize-backgroud .activity-prize-inner .title .title-font-prize{
    position: absolute;
    top: 25px;
    left: 132px;
    color: white;
    font-size: 18px;
  }
  .activity-prize-backgroud .activity-prize-inner .title .title-font-sponsor{
    position: absolute;
    top: 16px;
    left: 112px;
    color: white;
    font-size: 18px;
  }
  .activity-prize-backgroud .activity-prize-inner .middle-layout{
    display: flex;
    justify-content: space-around;
    margin-bottom: 20px;
  }
  .activity-prize-backgroud .activity-prize-inner .middle-layout img{
    width: 130px;
    height: 130px;
  }
  .activity-prize-backgroud .activity-prize-inner .middle-layout .prize-title{
    text-align: center;
    color: green;
    margin-bottom: 10px;
  }
  .activity-prize-backgroud .activity-prize-inner .bottom-layout{
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .activity-prize-backgroud .activity-prize-inner .bottom-layout img{
    width: 120px;
    height: auto;
    max-width: 100%;
    max-height: 100%; 
  }
  .activity-prize-backgroud .activity-prize-inner .copyright{
    text-align: center;
    font-size: 12px;
    color: #fff;
    z-index: 1;
    position: relative;
    top: 40px;
  }
  .bottom-background-img{
    width: 337px;
    margin: 0 auto;
    position: relative;
    top: -100px;
  }
  .bottom-background-img img{
    width: 100%;
    position: relative;
  }
  .background_left_top {
    position: absolute;
    left: 25px;
    top: 25px;
  }
  .background_left_top img {
    width: 120px;
    height: 40px;
  }
  .background_top_word {
    position: absolute;
    top: 65px;
    left: 35px;
  }
  .background_top_word img {
    width: 300px;
    height: 112px;
  }
  .background_car {
    position: absolute;
    top: 175px;
    left: 105px;
  }
  .background_car img {
    width: 160px;
    height: 120px;
  }
  .self .background_button_left {
    position: absolute;
    left: 45px;
    top: 50px;
  }
  .self .background_button_left img {
    width: 130px;
    height: 50px;
  }
  .self .background_button_right {
    position: absolute;
    left: 200px;
    top: 50px;
  }
  .self .background_button_right img {
    width: 130px;
    height: 50px;
  }
  .friend_assistant_0925 img {
    position: absolute;
    width: 319.5px;
    height: 40px;
    left: 27px;
    top: 632px;
    z-index: 180;
  }
  .rank_tag_self {

  }
  .rank_tag_self img {
    width: 30px;
    height: 24px;
    position: absolute;
    left: 230px;
    top: 117px;
  }
</style>
