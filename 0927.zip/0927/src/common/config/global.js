/*
* @Author: cdroid
* @Date:   2018-01-29 14:26:22
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-16 18:54:13
*/
/**
 * 定义全局参数
 */

// sentry DSN
const SENTRY_DSN = 'http://056ddc0c61c64d0cab5fc31b878851fd@10.1.16.74:8080/2'
// 优惠券阶梯一览数据
const ACTIVITYRULEDATA = [
   { rank: 1, assistance: 8, money: 5 },
   { rank: 2, assistance: 18, money: 8 },
   { rank: 3, assistance: 28, money: 13 },
   { rank: 4, assistance: 38, money: 20 },
   { rank: 5, assistance: 48, money: 28 },
   { rank: 6, assistance: 58, money: 40 },
   { rank: 7, assistance: 68, money: 55 },
   { rank: 8, assistance: 78, money: 68 },
   { rank: 9, assistance: 88, money: 88 },
   { rank: 10, assistance: 100000, money: 88 } ]
// 我的好友的数据
const FRIENDSLIST = [
   { id: '1', img: './../../static/adminImg.jpg', userName: '滚滚长江1', date: '1995-06-06 17:55:51' },
   { id: '2', img: './../../static/adminImg.jpg', userName: '滚滚长江2', date: '1995-06-06 17:55:52' },
   { id: '3', img: './../../static/adminImg.jpg', userName: '滚滚长江3', date: '1995-06-06 17:55:53' },
   { id: '4', img: './../../static/adminImg.jpg', userName: '滚滚长江4', date: '1995-06-06 17:55:54' }
   // { id: '5', img: './../../static/adminImg.jpg', userName: '滚滚长江5', date: '1995-06-06 17:55:55' },
   // { id: '6', img: './../../static/adminImg.jpg', userName: '滚滚长江6', date: '1995-06-06 17:55:56' },
   // { id: '7', img: './../../static/adminImg.jpg', userName: '滚滚长江7', date: '1995-06-06 17:55:57' }
]
// 排行榜的数据
const RANKDATAS = [
   { id: '1', rank: '1', img: './../../static/adminImg.jpg', nickName: '地球1', assistance: '11' },
   { id: '2', rank: '2', img: './../../static/adminImg.jpg', nickName: '地球2', assistance: '22' },
   { id: '3', rank: '3', img: './../../static/adminImg.jpg', nickName: '地球3', assistance: '33' },
   { id: '4', rank: '4', img: './../../static/adminImg.jpg', nickName: '地球4', assistance: '44' },
   { id: '5', rank: '5', img: './../../static/adminImg.jpg', nickName: '地球5', assistance: '55' },
   { id: '6', rank: '6', img: './../../static/adminImg.jpg', nickName: '地球6', assistance: '66' }
]
// stomp参数配置
// const webUrl = 'ws://10.1.16.117:9090/ws'  // rabbitmq连接url
// const rbUrl = '/exchange/fids.control/'   // exchange routing key等
// 1 行李转盘 RES_BAGGAGECAROUSEL  2 值机柜台  RES_CHECKINCOUNTER  3登机口 RES_GATE
// var linkTypeKeyValue = {'行李转盘': 1, '值机柜台': 2, '登机口': 3}

// 模板编辑器预览服务器地址
export const templatePreviewUrl = 'http://localhost:8080/#/'
export default {
  SENTRY_DSN,
  // webUrl,
  // rbUrl,
  // linkTypeKeyValue,
  ACTIVITYRULEDATA,
  FRIENDSLIST,
  RANKDATAS,
  templatePreviewUrl
}
