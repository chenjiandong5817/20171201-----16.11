/*
* @Author: chenjiandong
* @Date:   last_modified_time
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-01-29 17:10:11
*/
/*
 * @Author: chenyang
 * @Date: 2017-09-14 09:18:53
 * @Last Modified by: chenyang
 * @Last Modified time: 2017-09-14 10:51:21
 * 功能: 存放约定好的json格式,开关屏等操作的JSON
 */
function getJson (type, state, timestamp, data) {
  return {type, state, timestamp, data}
}

export default {
}
