/*
* @Author: cdroid
* @Date:   2018-03-06 10:08:13
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-03-07 10:47:23
*/
/*
 * @Author: chenyang
 * @Date: 2017-09-14 09:03:26
 * @Last Modified by: chenyang
 * @Last Modified time: 2017-10-27 11:07:42
 * 功能: 存放右键菜单对应的字段
 */
// let menuArray = ['清空缓存', '同步时间', '刷新界面', '应用升级', '更新播放列表', '关机', '重启', '检查设备状态', '下载多媒体信息', '亮屏', '灭屏', '上传应用错误日志']

export default {
  // menuArray
}
