/*
* @Author: cdroid
* @Date:   2018-01-29 17:15:36
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-02-28 10:43:49
*/
/*
* @Author: cdroid
* @Date:   2018-01-29 17:15:36
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-02-26 15:52:14
*/
/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:56:38
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-12-29 18:52:15
 * @Description:  vuex getter操作类
 */
// test
export const isLogin = (state) => {
  return (state.userStorage.user !== null && state.userStorage.token !== '')
}
export const getUserStorage = (state) => {
  return state.userStorage
}
