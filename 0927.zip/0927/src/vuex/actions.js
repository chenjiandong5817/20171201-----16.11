/*
* @Author: cdroid
* @Date:   2018-09-13 17:19:03
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-14 11:01:46
*/
/*
 * @Author: cdroid
 * @Date: 2017-05-25 10:56:16
 * @Last Modified by: cdroid
 * @Last Modified time: 2017-05-25 10:56:36
 * @Description:  vuex action操作类
 */
// after login
export const saveUserStorage = ({commit}, param) => {
  commit('saveUserStorage', param)
}

// remove login
export const removeUserStorage = ({commit}) => {
  commit('removeUserStorage')
}
