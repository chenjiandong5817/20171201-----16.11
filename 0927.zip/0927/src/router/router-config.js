/*
* @Author: chenjiandong
* @Date:   last_modified_time
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-19 18:25:50
*/

import NotFound from '../views/404'
import TheMidAutumnMain from '../views/TheMidAutumnMain'
import TheMidAutumnSelf from '../views/TheMidAutumnSelf'
import Explain from '../views/Explain'
import PrizeOne from '../views/prize-1'
import PrizeTwoThree from '../views/prize-2-3'
import success from '../views/success'
// 规则
import Rule from '../views/Rule'
import simulateAskTest from './../views/base/simulateAskTest'
// 基础表
let Component = {
  simulateasktest: simulateAskTest
}

let routes = [
  {
    id: 1500,
    path: '/',
    component: TheMidAutumnSelf,
    name: '',
    leaf: true,
    iconCls: 'el-icon-search',
    children: [
      { id: 1401, path: '/simulateasktest', name: '知识模拟问讯测试工具', components: Component }
    ]
  },
  {
    id: 1501,
    path: '/Explain',
    component: Explain,
    name: 'Explain',
    hidden: true
  },
  {
    id: 1502,
    path: '/PrizeOne',
    component: PrizeOne,
    name: 'PrizeOne',
    hidden: true
  },
  {
    id: 1503,
    path: '/PrizeTwoThree',
    component: PrizeTwoThree,
    name: 'PrizeTwoThree',
    hidden: true
  },
  {
    id: 9999,
    path: '/TheMidAutumnSelf',
    component: TheMidAutumnSelf,
    name: 'TheMidAutumnSelf',
    hidden: true
  },
  {
    id: 8888,
    path: '/Rule',
    component: Rule,
    name: 'Rule',
    hidden: true
  },
  {
    id: 8887,
    path: '/TheMidAutumnMain',
    component: TheMidAutumnMain,
    name: 'TheMidAutumnMain',
    hidden: true
  },
  {
    id: 8886,
    path: '/success/:param1',
    component: success,
    name: 'success',
    hidden: true
  },
  {
    id: 9998,
    path: '/404',
    component: NotFound,
    name: '',
    hidden: true
  },
  {
    id: 9997,
    path: '*',
    hidden: true,
    redirect: { path: '/404' }
  }
]

export default routes
