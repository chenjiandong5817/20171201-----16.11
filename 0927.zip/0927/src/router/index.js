/*
* @Author: chenjiandong
* @Date:   last_modified_time
* @Last Modified by:   chenjiandong
* @Last Modified time: 2018-09-17 17:48:05
*/
/*
* @Author: chenjiandong
* @Date:   2017-08-14 08:41:59
* @Last Modified by:   chenjiandong
* @Last Modified time: 2017-09-14 09:49:30
*/
import Vue from 'vue'
import Router from 'vue-router'
import RouterConfig from './router-config'
// import authorityHelper from './../common/js/authority-helper'
// import store from './../vuex/store'

Vue.use(Router)

var vueRouter = new Router({
  routes: RouterConfig
})
vueRouter.beforeEach((to, from, next) => {
  next()
  // if (to.path === '/theMidAutumnMain') {
  //   store.dispatch('removeUserStorage')
  // }
  // if (!store.getters.isLogin && to.path !== '/theMidAutumnMain') {
  //   next({ path: '/theMidAutumnMain' })
  // } else if (to.path === '/') {
  //   next({ path: '/home' })
  // } else {
  //   next()
  // }
})
export default vueRouter
